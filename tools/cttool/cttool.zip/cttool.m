function hout = cttool(varargin)
% entry

hout = imcttool(varargin{:});

end
